package com.beni.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private val requestAudio = 101
    private val requestContacts = 102
    private val requestCall = 103

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudio)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF101522.toInt())
        }
        val title = TextView(this).apply {
            text = "J A R V I S"
            textSize = 30f
            setTextColor(0xFF63D7FF.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "آماده‌ام. دکمه را بزن و فرمانت را بگو."
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 30, 0, 30)
        }
        val listen = Button(this).apply {
            text = "🎙 شروع شنیدن"
            textSize = 18f
            setOnClickListener { startListening() }
        }
        val hint = TextView(this).apply {
            text = "نسخهٔ آزمایشی: تشخیص گفتار به سرویس گفتار اندروید وابسته است."
            textSize = 13f
            setTextColor(0xFFB8C3D9.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        }
        root.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(listen, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(hint, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("سرویس تشخیص گفتار روی گوشی در دسترس نیست.")
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "فرمانت را بگو")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        }
        status.text = "دارم گوش می‌دهم…"
        try {
            startActivityForResult(intent, 200)
        } catch (e: Exception) {
            status.text = "تشخیص گفتار شروع نشد."
            speak("نتوانستم شنیدن را شروع کنم.")
        }
    }

    @Deprecated("Deprecated in Android API; retained for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 200) return
        if (resultCode == RESULT_OK) {
            val matches = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val command = matches?.firstOrNull().orEmpty()
            status.text = if (command.isBlank()) "صدایی تشخیص داده نشد." else "شنیدم: $command"
            handleCommand(command)
        } else {
            status.text = "شنیدن لغو شد یا نتیجه‌ای نرسید."
        }
    }

    private fun handleCommand(raw: String) {
        val command = raw.lowercase(Locale.ROOT).replace("‌", " ").trim()
        when {
            command.contains("تلگرام") -> openApp("org.telegram.messenger", "تلگرام")
            command.contains("واتساپ") || command.contains("واتس اپ") -> openApp("com.whatsapp", "واتساپ")
            command.contains("یوتیوب") -> openApp("com.google.android.youtube", "یوتیوب")
            command.contains("تنظیمات") -> {
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
                speak("تنظیمات را باز کردم.")
            }
            command.contains("مامان") || command.contains("مادر") || command.contains("mom") -> callContact("Mom")
            command.contains("علی") || command.contains("ali") -> callContact("Ali")
            command.contains("سلام") || command.contains("جاربیس") || command.contains("jarvis") -> speak("سلام، من جاربیس هستم. چه کاری انجام بدهم؟")
            else -> speak("این فرمان را هنوز یاد نگرفته‌ام.")
        }
    }

    private fun openApp(packageName: String, appName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            speak("$appName را باز کردم.")
        } else {
            speak("$appName روی گوشی پیدا نشد.")
        }
    }

    private fun callContact(name: String) {
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), requestContacts)
            speak("برای پیدا کردن مخاطب، اجازهٔ مخاطبین را بده و دوباره فرمان را بگو.")
            return
        }
        val phone = findPhone(name)
        if (phone.isNullOrBlank()) {
            speak("شمارهٔ $name را در مخاطبین پیدا نکردم.")
            return
        }
        val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$phone"))
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CALL_PHONE), requestCall)
            speak("برای تماس، اجازهٔ تماس را بده و دوباره فرمان را بگو.")
            return
        }
        startActivity(callIntent)
    }

    private fun findPhone(target: String): String? {
        val cursor = contentResolver.query(
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null, null
        ) ?: return null
        cursor.use {
            while (it.moveToNext()) {
                val display = it.getString(0) ?: continue
                val number = it.getString(1) ?: continue
                if (display.contains(target, ignoreCase = true)) return number
            }
        }
        return null
    }

    private fun speak(text: String) {
        status.text = text
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("fa", "IR"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                runOnUiThread { status.text = "موتور گفتار گوشی ممکن است فارسی را پشتیبانی نکند." }
            }
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
